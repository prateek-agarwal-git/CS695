import sys, os
fp = open("f1.txt", "w")
a = "aaaaaaaaa\n"*40
fp.write(a)
fp.close()